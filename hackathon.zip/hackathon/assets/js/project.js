$(document).ready(function(){
    // everything here will be executed once index.html has finished loading, so at the start when the user is yet to do anything.
    $("#select1").change(load_new_content()); //this translates to: "when the element with id='select1' changes its value execute load_new_content() function"
    function load_new_content(){
        var selected_option_value=$("#select1 option:selected").val(); //get the value of the current selected option.
   
        $.post("script_that_receives_value.php", {option_value: selected_option_value},
            function(data){ //this will be executed once the `script_that_receives_value.php` ends its execution, `data` contains everything said script echoed.
                 $("#place_where_you_want_the_new_html").html(data);
                 alert(data); //just to see what it returns
            }
        );
   }
});