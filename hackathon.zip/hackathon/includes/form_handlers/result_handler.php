<?php 

    if(isset($_POST['result_btn'])){
        $entered_email = $_POST['result_email'];
        $check1 = mysqli_query($con,"SELECT * from team_members WHERE first_member_email='$entered_email'");
        $check2 = mysqli_query($con,"SELECT * from team_members WHERE second_member_email='$entered_email'");
        $check3 = mysqli_query($con,"SELECT * from team_members WHERE third_member_email='$entered_email'");
        $check4 = mysqli_query($con,"SELECT * from team_members WHERE fourth_member_email='$entered_email'");
        $check5 = mysqli_query($con,"SELECT * from team_members WHERE fifth_member_email='$entered_email'");
        $check6 = mysqli_query($con,"SELECT * from team_members WHERE sixth_member_email='$entered_email'");

        $num_rows1 = mysqli_num_rows($check1);
        $num_rows2 = mysqli_num_rows($check2);
        $num_rows3 = mysqli_num_rows($check3);
        $num_rows4 = mysqli_num_rows($check4);
        $num_rows5 = mysqli_num_rows($check5);
        $num_rows6 = mysqli_num_rows($check6);

        if($num_rows1 > 0 ){
            $row = mysqli_fetch_array($check_database_query);
        }
        else if($num_rows2 > 0 ){
            $row = mysqli_fetch_array($check_database_query);      
          }
        else if($num_rows3 > 0 ){
            $row = mysqli_fetch_array($check_database_query);
        }
        else if($num_rows4 > 0 ){
            $row = mysqli_fetch_array($check_database_query);
        }
        else if($num_rows5 > 0 ){
            $row = mysqli_fetch_array($check_database_query);
        }
        else if($num_rows6 > 0 ){
            $row = mysqli_fetch_array($check_database_query);
        }
        else{
            $row = "";
        }
        $_SESSION['selected'] = $row['selected'];
        $_SESSION['selected_project'] = $row['project_title'];
        $_SESSION['selected_project_des'] = $row['project_description'];
        $_SESSION['selected_first_name'] = $row['first_member_name'];
        $_SESSION['selected_second_name']= $row['second_member_name'];
        $_SESSION['selected_third_name'] = $row['third_member_name'];
        $_SESSION['selected_fourth_name'] = $row['fourth_member_name'];
        $_SESSION['selected_fifth_name'] = $row['fifth_member_name'];
        $_SESSION['selected_sixth_name'] = $row['sixth_member_name'];
    }

?>