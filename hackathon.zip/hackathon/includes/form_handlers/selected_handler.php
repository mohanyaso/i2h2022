<?php
    $tid = ""; 
    if(isset($_POST['selected_btn'])){
        $tid = $_POST['selected_id']; 
        $select_query = mysqli_query($con,"UPDATE team_members SET selected = 'yes' WHERE team_id = '$tid'");
        $theme_query = mysqli_query($con,"SELECT project_theme FROM team_members WHERE team_id = '$tid'");
        $theme_array = mysqli_fetch_array($theme_query);
        $theme_query = mysqli_query($con,"SELECT * FROM team_members WHERE team_id = '$tid'");
        $theme_array = mysqli_fetch_array($theme_query);
        $select_theme = $theme_array['project_theme'];
        $_SESSION['selected_theme'] = $select_theme;
    }
    if(isset($_POST['rejected_btn'])){
        $tid = $_POST['selected_id']; 
        $select_query = mysqli_query($con,"UPDATE team_members SET selected = 'no' WHERE team_id = '$tid'");
        $theme_query = mysqli_query($con,"SELECT * FROM team_members WHERE team_id = '$tid'");
        $theme_array = mysqli_fetch_array($theme_query);
        $select_theme = $theme_array['project_theme'];
        $_SESSION['selected_theme'] = $select_theme;
    }
    if(isset($_POST['theme_submit'])){
        $st = $_POST['admin_project_theme'];
        $_SESSION['selected_theme'] = $st;

    }
?>