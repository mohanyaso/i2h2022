<?php

    $theme = "";
    $title = "";
    $desc = "";
    $themme_short = "";
    $id_start = "I2H";
    $input_id = "";
    $h_p = "";
    $a_p = "";
    $theme_submitted = "";
    $list_to_display = "";
    $_SESSION['theme_s_for_ps'] = 'Healthcare';
    
    if(isset($_POST['back_btn'])){
        header("Location: index.php");
        exit();
    }

    if(isset($_POST['theme_submit'])){
        $_SESSION['theme_s_for_ps'] = $_POST['project_theme'];
        $theme_submitted = $_POST['project_theme'];
        $_SESSION['theme_submitted'] = $theme_submitted;
        if($theme_submitted == 'Healthcare'){
            $list_to_display .= "
            <select class='form-select form-select-md' style='width:90%;padding:5px;' id='theme' name='problem_statement' aria-label='Default select example' required>
                <option selected>Select problem statement</option>
                <option value='Health Preventative Services'>1.	Health Preventative Services</option>
                <option value='Public Health and Surveillance'>2.	Public Health and Surveillance</option>
                <option value='Health Disparities for Persons with Disabilities'>3.   Health Disparities for Persons with Disabilities</option>
                <option value='Health Care Access and Quality'>4.	Health Care Access and Quality</option>
                <option value='CAT scans and myelograms'>5.   CAT scans and myelograms</option>
                <option value='Establish health application systems'>6.	Establish health application systems</option>
                <option value='AI -Solve drug design'>7.	AI -Solve drug design</option>
                <option value='Open innovation'>8.	Open innovation</option>
            </select>
            ";
        }

        if($theme_submitted == 'Agriculture'){
            $list_to_display .= "
            <select class='form-select form-select-md' style='width:90%;' id='theme' name='problem_statement' aria-label='Default select example' required>
                <option selected>Select problem statement</option>
                <option value='Improvement in the design of food storage structures'>1.	Improvement in the design of food storage structures</option>
                <option value='IoT enabled micro irrigation'>2.	IoT enabled micro irrigation  </option>
                <option value='Eco-Harvester for fruits'>3.	Eco-Harvester for fruits </option>
                <option value='Postharvest Processing.'>4.	Postharvest Processing.</option>
                <option value='Detection of bacterial and fungal infections in plants. '>5.	Detection of bacterial and fungal infections in plants. </option>
                <option value='To help farmers to identify and implement innovative technology'>6.	To help farmers to identify and implement innovative technology </option>
                <option value='Open innovation'>7.	Open innovation</option>
            </select>
            ";
        }

        if($theme_submitted == 'Open innovation' || $theme_submitted == 'Environment'){
            $list_to_display .= "
            <select class='form-select form-select-md' style='width:90%;' id='theme' name='problem_statement' aria-label='Default select example' required>
                <option value='Open innovation'>Open innovation</option>
            </select>
            ";
        }

    }

    if(isset($_POST['project_submit'])){

        $leader_name = $_SESSION['leader_name'];
        $title = $_POST['project_name'];
        $p_s = $_POST['problem_statement'];
        $_SESSION['project_name'] = $title;
        $desc = $_POST['project_des'];
        // $desc = preg_replace('~^["]?(.*?)["]?$~', '$1', $desc); 
        $desc = str_replace("'", " ", $desc);
        $desc = str_replace('""', "", $desc); 
        $_SESSION['project_des'] = $desc;

        $id_query = mysqli_query($con,"SELECT * from team_members WHERE project_title = ''"); 
        $access_id_array = mysqli_fetch_array($id_query);
        $l_name = $access_id_array['leader_name'];
        $access_id = $access_id_array['access_id'];
        $leader_email = $access_id_array['leader_email'];
        $theme = $_SESSION['theme_submitted'];
        $_SESSION['project_theme'] = $theme;
        $short =  strtolower($theme);
        $themme_short = substr($short, 0, 2); 
        $id_start .= $themme_short . $access_id;

        $update_query = mysqli_query($con,"UPDATE team_members SET problem_statement = '$p_s', team_id = '$id_start', project_theme = '$theme', project_title = '$title', project_description = '$desc' WHERE access_id = '$access_id'");
        
        $_SESSION['selected_theme'] = $theme;
        $to      = $leader_email;
        $subject = 'Registeration Successful !';
        $message = "Dear' . $leader_name . ',' .'\nCongratulations!\n' .'Your Team has been registered for Sri Eshwar's Intelligent and Innovators Hackathon 2022"
        . "You are requested to come prepared with your team (and mentor if required from your side) for the 36 hours continuous coding.\nYou need to be available in the venue on 4th & 5th November 2022";
        $headers = 'From: secei2h2022@gmail.com';
        mail($to, $subject, $message, $headers);
        header("Location: message.php");
        exit();
        // session_destroy();
        // session_start();
    }

?>