<?php

    $name = "";
    $em = "";
    $em2 = "";
    $org_type = "";
    $phone = "";
    $designation = "";
    $department = "";
    $org = "";
    $country = "";
    $state = "";
    $city = "";
    $password = "";
    $password2 = "";
    $error_array = array();

    if(isset($_POST["register_button"])){

        $name = strip_tags($_POST["reg_name"]);
        $name = str_replace(' ','',$name);
        $name = ucfirst(strtolower($name));
        $_SESSION['reg_name'] = $name;
        $_SESSION['username'] = $name;

        $em = strip_tags($_POST['reg_email']);
        $em = str_replace(' ','',$em);
        $_SESSION['reg_email'] = $em;

        $org_type = strip_tags($_POST['reg_org_type']);
        $org_type = str_replace(' ','',$org_type);
        $_SESSION['reg_org_type'] = $org_type;

        $phone = $_POST['reg_phone'];
        $_SESSION['reg_phone'] = $phone;

        $designation = strip_tags($_POST['reg_designation']);
        $designation = str_replace(' ','',$designation);
        $_SESSION['reg_designation'] = $designation;

        $department = strip_tags($_POST['reg_department']);
        $department = str_replace(' ','',$department);
        $_SESSION['reg_department'] = $department;

        $org = strip_tags($_POST['reg_org']);
        $orf = str_replace(' ','',$org);
        $_SESSION['reg_org'] = $org;

        $country = strip_tags($_POST['country']);
        $country = str_replace(' ','',$country);
        $_SESSION['country'] = $country;

        $state = strip_tags($_POST['state']);
        $state = str_replace(' ','',$state);
        $_SESSION['state'] = $state;

        $city = strip_tags($_POST['reg_city']);
        $city = str_replace(' ','',$city);
        $_SESSION['reg_city'] = $city;

        $password = strip_tags($_POST['reg_password']);
        $password2 = strip_tags($_POST['reg_password2']);

        if(filter_var($em,FILTER_VALIDATE_EMAIL)){
            $em = filter_var($em,FILTER_VALIDATE_EMAIL);

            $echeck = mysqli_query($con,"SELECT email from users WHERE email='$em'");

            $num_rows = mysqli_num_rows($echeck);

            if($num_rows > 0){
                array_push($error_array,"Email already in use<br>");
            }
        }
        else{
            array_push($error_array,"INVALID EMAIL FORMAT<br>");
        }

        if(strlen($name) > 25 || strlen($name) < 2){
            array_push($error_array,"Your first name must be between 2 and 25 characters<br>");
        }
        if($password != $password2){
            array_push($error_array,"Your passwords do not match<br>");
        }
        else{
            if(preg_match('/[^A-Za-z0-9]/',$password)){
                array_push($error_array,"Your password can only contain alphabets and numbers<br>");
            }
        }

        if(strlen($password) > 30 || strlen($password) < 5){
            array_push($error_array,"Your password must be between 5 and 30 characters<br>");
        }

        if(empty($error_array)){
            $password = md5($password);
            $username = strtolower($name);
            // $check_username_query = mysqli_query($con,"SELECT username FROM users WHERE name = '$name'");
            // $i=0;
            $query = mysqli_query($con,"INSERT INTO users VALUES('','$username','$em','$password','','$org_type','$phone','$designation','$department','$org','$country','$state','$city')");

            array_push($error_array,"<span style='color: #14C800;'>You are all set! Go ahead and Login!</span><br>");
            $_SESSION['reg_name'] = "";
            $_SESSION['reg_email'] = "";
            $_SESSION['reg_org_type'] = "";
            $_SESSION['reg_phone'] = "";
            $_SESSION['reg_designation'] = "";
            $_SESSION['reg_department'] = "";
            $_SESSION['reg_org'] = "";
            $_SESSION['reg_city'] = "";
            // session_destroy();
            // $_SESSION['name'] = $username;
            header("Location: index.php");
            exit();
        }
        

    }

?>