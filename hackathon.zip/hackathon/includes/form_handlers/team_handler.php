<?php

    $fname = "";
    $fem = "";
    $fphone = "";
    $forg = "";
    $fyear = "";
    $fdep = "";

    $sename = "";
    $seem = "";
    $sephone = "";
    $sorg = "";
    $syear = "";
    $sdep = "";

    $tname = "";
    $tem = "";
    $tphone = "";
    $torg = "";
    $tyear = "";
    $tdep = "";

    $lname = "";
    $lem = "";
    $lphone = "";
    $lorg = "";
    $lyear = "";
    $ldep = "";

    $mname = "";
    $mem = "";
    $mphone = "";
    $morg = "";
    $mdes = "";
    $mdep = "";

    $error_array = [];
    $closed = '';
    $display = '';

    $date = date("d");
    $month = date("m");
    if($date >= 6 && $month >= 10) {
        $closed = 'disabled';
        $display = 'Registration Closed';
    }
    else{
        $display = 'Registration Form';
    }
    
    if(isset($_POST['cancel_submit'])){
        header("Location: index.php");
        exit();
    }

    
    if(isset($_POST['member_submit'])){
        $fname = strip_tags($_POST['first_name']);
        $fname = str_replace(' ','',$fname);
        $fname = ucfirst(strtolower($fname));
        $_SESSION['first_name'] = $fname;

        $fem = strip_tags($_POST['first_email']);
        $fem = str_replace(' ','',$fem);
        $_SESSION['first_email'] = $fem;

        $fphone = $_POST['first_phone'];
        $_SESSION['first_phone'] = $fphone;
        
        $forg = strip_tags($_POST['first_org']);
        $forg = str_replace(' ','',$forg);
        $_SESSION['first_org'] = $forg;

        $fyear = $_POST['first_year'];
        $_SESSION['first_year'] = $fyear;

        $fdep = strip_tags($_POST['first_dep']);
        $fdep = str_replace(' ','',$fdep);
        $_SESSION['first_dep'] = $fdep;

        $sename = strip_tags($_POST['second_name']);
        $sename = str_replace(' ','',$sename);
        $sename = ucfirst(strtolower($sename));
        $_SESSION['second_name'] = $sename;

        $seem = strip_tags($_POST['second_email']);
        $seem = str_replace(' ','',$seem);
        $_SESSION['second_email'] = $seem;

        $sephone = $_POST['second_phone'];
        $_SESSION['second_phone'] = $sephone;
        
        $sorg = strip_tags($_POST['second_org']);
        $sorg = str_replace(' ','',$sorg);
        $_SESSION['second_org'] = $sorg;

        $syear = $_POST['second_year'];
        $_SESSION['second_year'] = $syear;

        $sdep = strip_tags($_POST['second_dep']);
        $sdep = str_replace(' ','',$sdep);
        $_SESSION['second_dep'] = $sdep;

        $tname = strip_tags($_POST['third_name']);
        $tname = str_replace(' ','',$tname);
        $tname = ucfirst(strtolower($tname));
        $_SESSION['third_name'] = $tname;

        $tem = strip_tags($_POST['third_email']);
        $tem = str_replace(' ','',$tem);
        $_SESSION['third_email'] = $tem;

        $tphone = $_POST['third_phone'];
        $_SESSION['third_phone'] = $tphone;

        $torg = strip_tags($_POST['third_org']);
        $torg = str_replace(' ','',$torg);
        $_SESSION['third_org'] = $torg;

        $tyear = $_POST['third_year'];
        $_SESSION['third_year'] = $tyear;

        $tdep = strip_tags($_POST['third_dep']);
        $tdep = str_replace(' ','',$tdep);
        $_SESSION['third_dep'] = $tdep;


        $lname = strip_tags($_POST['leader_name']);
        $lname = str_replace(' ','',$lname);
        $lname = ucfirst(strtolower($lname));
        $_SESSION['leader_name'] = $lname;

        $lem = strip_tags($_POST['leader_email']);
        $lem = str_replace(' ','',$lem);
        $_SESSION['leader_email'] = $lem;

        $lphone = $_POST['leader_phone'];
        $_SESSION['leader_phone'] = $lphone;

        $lorg = strip_tags($_POST['leader_org']);
        $lorg = str_replace(' ','',$lorg);
        $_SESSION['leader_org'] = $lorg;

        $lyear = $_POST['leader_year'];
        $_SESSION['leader_year'] = $lyear;

        $ldep = strip_tags($_POST['leader_dep']);
        $ldep = str_replace(' ','',$ldep);
        $_SESSION['leader_dep'] = $ldep;

        $mname = strip_tags($_POST['mentor_name']);
        $mname = str_replace(' ','',$mname);
        $mname = ucfirst(strtolower($mname));
        $_SESSION['mentor_name'] = $mname;

        $mem = strip_tags($_POST['mentor_email']);
        $mem = str_replace(' ','',$mem);
        $_SESSION['mentor_email'] = $mem;

        $mphone = $_POST['mentor_phone'];
        $_SESSION['mentor_phone'] = $mphone;

        $morg = strip_tags($_POST['mentor_org']);
        $morg = str_replace(' ','',$morg);
        $_SESSION['mentor_org'] = $morg;

        $mdes = $_POST['mentor_des'];
        $_SESSION['mentor_year'] = $mdes;

        $mdep = strip_tags($_POST['mentor_dep']);
        $mdep = str_replace(' ','',$mdep);
        $_SESSION['mentor_dep'] = $mdep;

        if($fem != ''){

            if(filter_var($fem,FILTER_VALIDATE_EMAIL)){
                $fem = filter_var($fem,FILTER_VALIDATE_EMAIL);
    
                $e11check = mysqli_query($con,"SELECT * from team_members WHERE first_member_email='$fem'");
                $e12check = mysqli_query($con,"SELECT * from team_members WHERE second_member_email='$fem'");
                $e13check = mysqli_query($con,"SELECT * from team_members WHERE third_member_email='$fem'");
                $e15check = mysqli_query($con,"SELECT * from team_members WHERE leader_email='$fem'");
                $e16check = mysqli_query($con,"SELECT * from team_members WHERE mentor_email='$fem'");
    
                
    
                $num1_rows = mysqli_num_rows($e11check);
                $num2_rows = mysqli_num_rows($e12check);
                $num3_rows = mysqli_num_rows($e13check);
                $num5_rows = mysqli_num_rows($e15check);
                $num6_rows = mysqli_num_rows($e16check);
    
    
                if($num1_rows > 0 || $num2_rows > 0 || $num3_rows > 0 || $num4_rows > 0 || $num5_rows > 0 || $num6_rows > 0 ){
                    array_push($error_array,"Email already in use<br>");
                }
            }
            else{
                array_push($error_array,"INVALID EMAIL FORMAT<br>");
            }

        }

        if($sem != ''){

            if(filter_var($fem,FILTER_VALIDATE_EMAIL) || filter_var($seem,FILTER_VALIDATE_EMAIL) || filter_var($tem,FILTER_VALIDATE_EMAIL) || filter_var($foem,FILTER_VALIDATE_EMAIL)){
                $seem = filter_var($seem,FILTER_VALIDATE_EMAIL);
    
                $e21check = mysqli_query($con,"SELECT * from team_members WHERE first_member_email='$seem'");
                $e22check = mysqli_query($con,"SELECT * from team_members WHERE second_member_email='$seem'");
                $e23check = mysqli_query($con,"SELECT * from team_members WHERE third_member_email='$seem'");
                $e25check = mysqli_query($con,"SELECT * from team_members WHERE leader_email='$seem'");
                $e26check = mysqli_query($con,"SELECT * from team_members WHERE mentor_email='$seem'");
    
    
                $num25_rows = mysqli_num_rows($e21check);
                $num26_rows = mysqli_num_rows($e22check);
                $num7_rows = mysqli_num_rows($e23check);
                $num27_rows = mysqli_num_rows($e25check);
                $num28_rows = mysqli_num_rows($e26check);
    
    
                if($num7_rows > 0 || $num8_rows > 0  ||  $num25_rows > 0 || $num26_rows > 0 || $num27_rows > 0 || $num28_rows > 0 ){
                    array_push($error_array,"Email already in use<br>");
                }
            }
            else{
                array_push($error_array,"INVALID EMAIL FORMAT<br>");
            }

        }

        if($tem != ''){
            if(filter_var($fem,FILTER_VALIDATE_EMAIL) || filter_var($seem,FILTER_VALIDATE_EMAIL) || filter_var($tem,FILTER_VALIDATE_EMAIL) || filter_var($foem,FILTER_VALIDATE_EMAIL)){

                $tem = filter_var($tem,FILTER_VALIDATE_EMAIL);

                $e31check = mysqli_query($con,"SELECT * from team_members WHERE first_member_email='$tem'");
                $e32check = mysqli_query($con,"SELECT * from team_members WHERE second_member_email='$tem'");
                $e33check = mysqli_query($con,"SELECT * from team_members WHERE third_member_email='$tem'");
                $e35check = mysqli_query($con,"SELECT * from team_members WHERE leader_email='$tem'");
                $e36check = mysqli_query($con,"SELECT * from team_members WHERE mentor_email='$tem'");
                
    
                $num9_rows = mysqli_num_rows($e31check);
                $num10_rows = mysqli_num_rows($e32check);
                $num11_rows = mysqli_num_rows($e33check);
                $num29_rows = mysqli_num_rows($e35check);
                $num30_rows = mysqli_num_rows($e36check);
    
    
                if($num9_rows > 0 || $num10_rows > 0 || $num11_rows > 0 || $num12_rows > 0 || $num29_rows > 0 || $num30_rows > 0){
                    array_push($error_array,"Email already in use<br>");
                }
            }
            else{
                array_push($error_array,"INVALID EMAIL FORMAT<br>");
            }
        }

 



        // if(filter_var($fem,FILTER_VALIDATE_EMAIL) || filter_var($seem,FILTER_VALIDATE_EMAIL) || filter_var($tem,FILTER_VALIDATE_EMAIL) || filter_var($foem,FILTER_VALIDATE_EMAIL)){
        //     $fem = filter_var($fem,FILTER_VALIDATE_EMAIL);
        //     $seem = filter_var($seem,FILTER_VALIDATE_EMAIL);
        //     $tem = filter_var($tem,FILTER_VALIDATE_EMAIL);
        //     $foem = filter_var($foem,FILTER_VALIDATE_EMAIL);

        //     $e11check = mysqli_query($con,"SELECT * from team_members WHERE first_member_email='$fem'");
        //     $e12check = mysqli_query($con,"SELECT * from team_members WHERE second_member_email='$fem'");
        //     $e13check = mysqli_query($con,"SELECT * from team_members WHERE third_member_email='$fem'");
        //     $e14check = mysqli_query($con,"SELECT * from team_members WHERE fourth_member_email='$fem'");
        //     $e15check = mysqli_query($con,"SELECT * from team_members WHERE leader_email='$fem'");
        //     $e16check = mysqli_query($con,"SELECT * from team_members WHERE mentor_email='$fem'");

        //     $e21check = mysqli_query($con,"SELECT * from team_members WHERE first_member_email='$seem'");
        //     $e22check = mysqli_query($con,"SELECT * from team_members WHERE second_member_email='$seem'");
        //     $e23check = mysqli_query($con,"SELECT * from team_members WHERE third_member_email='$seem'");
        //     $e24check = mysqli_query($con,"SELECT * from team_members WHERE fourth_member_email='$seem'");
        //     $e25check = mysqli_query($con,"SELECT * from team_members WHERE leader_email='$seem'");
        //     $e26check = mysqli_query($con,"SELECT * from team_members WHERE mentor_email='$seem'");

        //     $e31check = mysqli_query($con,"SELECT * from team_members WHERE first_member_email='$tem'");
        //     $e32check = mysqli_query($con,"SELECT * from team_members WHERE second_member_email='$tem'");
        //     $e33check = mysqli_query($con,"SELECT * from team_members WHERE third_member_email='$tem'");
        //     $e34check = mysqli_query($con,"SELECT * from team_members WHERE fourth_member_email='$tem'");
        //     $e35check = mysqli_query($con,"SELECT * from team_members WHERE leader_email='$tem'");
        //     $e36check = mysqli_query($con,"SELECT * from team_members WHERE mentor_email='$tem'");

        //     $e41check = mysqli_query($con,"SELECT * from team_members WHERE first_member_email='$foem'");
        //     $e42check = mysqli_query($con,"SELECT * from team_members WHERE second_member_email='$foem'");
        //     $e43check = mysqli_query($con,"SELECT * from team_members WHERE third_member_email='$foem'");
        //     $e44check = mysqli_query($con,"SELECT * from team_members WHERE fourth_member_email='$foem'");
        //     $e45check = mysqli_query($con,"SELECT * from team_members WHERE leader_email='$foem'");
        //     $e46check = mysqli_query($con,"SELECT * from team_members WHERE mentor_email='$foem'");

            

        //     $num1_rows = mysqli_num_rows($e11check);
        //     $num2_rows = mysqli_num_rows($e12check);
        //     $num3_rows = mysqli_num_rows($e13check);
        //     $num4_rows = mysqli_num_rows($e14check);
        //     $num5_rows = mysqli_num_rows($e15check);
        //     $num6_rows = mysqli_num_rows($e16check);

        //     $num25_rows = mysqli_num_rows($e21check);
        //     $num26_rows = mysqli_num_rows($e22check);
        //     $num7_rows = mysqli_num_rows($e23check);
        //     $num8_rows = mysqli_num_rows($e24check);
        //     $num27_rows = mysqli_num_rows($e25check);
        //     $num28_rows = mysqli_num_rows($e26check);

        //     $num9_rows = mysqli_num_rows($e31check);
        //     $num10_rows = mysqli_num_rows($e32check);
        //     $num11_rows = mysqli_num_rows($e33check);
        //     $num12_rows = mysqli_num_rows($e34check);
        //     $num29_rows = mysqli_num_rows($e35check);
        //     $num30_rows = mysqli_num_rows($e36check);

        //     $num13_rows = mysqli_num_rows($e41check);
        //     $num14_rows = mysqli_num_rows($e42check);
        //     $num15_rows = mysqli_num_rows($e43check);
        //     $num16_rows = mysqli_num_rows($e44check);
        //     $num31_rows = mysqli_num_rows($e45check);
        //     $num32_rows = mysqli_num_rows($e46check);


        //     if($num1_rows > 0 || $num2_rows > 0 || $num3_rows > 0 || $num4_rows > 0 || $num5_rows > 0 || $num6_rows > 0 || $num7_rows > 0 || $num8_rows > 0 || $num9_rows > 0 || $num10_rows > 0 || $num11_rows > 0 || $num12_rows > 0 || $num13_rows > 0 || $num14_rows > 0 || $num15_rows > 0 || $num16_rows > 0 || $num25_rows > 0 || $num26_rows > 0 || $num27_rows > 0 || $num28_rows > 0 || $num29_rows > 0 || $num30_rows > 0 || $num31_rows > 0 || $num32_rows > 0){
        //         array_push($error_array,"Email already in use<br>");
        //     }
        // }
        // else{
        //     array_push($error_array,"INVALID EMAIL FORMAT<br>");
        // }

        // if(strlen($fname) > 25 || strlen($fname) < 2 || strlen($sename) > 25 || strlen($sename) < 2 || strlen($tname) > 25 || strlen($tname) < 2 || strlen($foname) > 25 || strlen($foname) < 2){
        //     array_push($error_array,"Name must be between 2 and 25 characters<br>");
        // }

        if(filter_var($lem,FILTER_VALIDATE_EMAIL)){
            $lem = filter_var($lem,FILTER_VALIDATE_EMAIL);


            $e51check = mysqli_query($con,"SELECT * from team_members WHERE first_member_email='$lem'");
            $e52check = mysqli_query($con,"SELECT * from team_members WHERE second_member_email='$lem'");
            $e53check = mysqli_query($con,"SELECT * from team_members WHERE third_member_email='$lem'");
            $e55check = mysqli_query($con,"SELECT * from team_members WHERE leader_email='$lem'");
            $e56check = mysqli_query($con,"SELECT * from team_members WHERE mentor_email='$lem'");
            

            $num17_rows = mysqli_num_rows($e51check);
            $num18_rows = mysqli_num_rows($e52check);
            $num19_rows = mysqli_num_rows($e53check);
            $num33_rows = mysqli_num_rows($e55check);
            $num34_rows = mysqli_num_rows($e56check);

            if($num17_rows > 0 || $num18_rows > 0 || $num19_rows > 0 || $num20_rows > 0 || $num33_rows > 0 || $num34_rows > 0){
                array_push($error_array,"Email already in use<br>");
            }
        }
        else{
            $lem = "";
            $lname= "";
            $lphone = "";
            $_SESSION['leader_email'] = "";
        }
        // if(strlen($lname) > 25 || strlen($lname) < 2){
        //     array_push($error_array,"Name must be between 2 and 25 characters<br>");
        // }

        if($mem != ''){
            if(filter_var($mem,FILTER_VALIDATE_EMAIL)){
                $mem = filter_var($mem,FILTER_VALIDATE_EMAIL);

                $e61check = mysqli_query($con,"SELECT * from team_members WHERE first_member_email='$mem'");
                $e62check = mysqli_query($con,"SELECT * from team_members WHERE second_member_email='$mem'");
                $e63check = mysqli_query($con,"SELECT * from team_members WHERE third_member_email='$mem'");
                $e65check = mysqli_query($con,"SELECT * from team_members WHERE leader_email='$mem'");
                $e66check = mysqli_query($con,"SELECT * from team_members WHERE mentor_email='$mem'");

                $num21_rows = mysqli_num_rows($e61check);
                $num22_rows = mysqli_num_rows($e62check);
                $num23_rows = mysqli_num_rows($e63check);
                $num35_rows = mysqli_num_rows($e65check);
                $num36_rows = mysqli_num_rows($e65check);

                if($num21_rows > 0 || $num22_rows > 0 || $num23_rows > 0 || $num24_rows > 0 || $num35_rows > 0 || $num36_rows > 0 ){
                    array_push($error_array,"Email already in use<br>");
                }
            }
            else{
                $mem = "";
                $mname= "";
                $mphone = "";
                $_SESSION['mentor_email'] = "";
            }
        }

        // if(strlen($mname) > 25 || strlen($mname) < 2){
        //     array_push($error_array,"Name must be between 2 and 25 characters<br>");
        // }


        if(empty($error_array)){
            // echo '<script>alert("Welcome to Geeks for Geeks")</script>';
            $username1 = strtolower($fname);
            $username2 = strtolower($sename);
            $username3 = strtolower($tname);
            $username4 = strtolower($foname);
            $username5 = strtolower($lname);
            $username6 = strtolower($mname);
            
                
            $query = mysqli_query($con,"INSERT INTO team_members VALUES('$username5','$lem','$lphone','$lorg','$lyear','$ldep','$username6','$mem','$mphone','$morg','$mdes','$mdep','$username1','$fem','$fphone','$forg','$fyear','$fdep','$username2','$seem','$sephone','$sorg','$syear','$sdep','$username3','$tem','$tphone','$torg','$tyear','$tdep','','','','','yet','','')");

            // array_push($error2_array,"<span style='color: #14C800;'>You are all set! All the best</span><br>");

           
            $_SESSION['pop_up'] = "yes";
            $_SESSION['first_name'] = $fname;
            $_SESSION['error'] = "";
            header("Location: abstract.php");
            exit();
        }
        else{
            $_SESSION['error'] = $error_array[0];
            header("Location: form.php");
            exit();
        }
        

    }

?>