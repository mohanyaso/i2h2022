<?php 

    if(isset($_POST['admin_login_button'])){
        $admin_name = filter_var($_POST['admin_name']);
        $_SESSION['admin_name'] = "$admin_name";

        $admin_password = $_POST['admin_password'];
        $_SESSION['admin_password'] = $_POST['admin_password'];

        $check_database_query = mysqli_query($con,"SELECT * FROM admin WHERE admin_name = '$admin_name' AND admin_password = '$admin_password'");
        $check_login_query = mysqli_num_rows($check_database_query);

        if($check_login_query == 1){
            $row = mysqli_fetch_array($check_database_query);
            $admin_name =$row['admin_name'];
            $_SESSION['admin_name'] = $admin_name;
            header("Location: admin.php");
            exit();
        }

        else{
            array_push($error_array,"Email or Password was incorrect<br>");
        }
    }
?>