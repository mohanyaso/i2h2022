<?php

    $healthcare = "";
    $agri = "";
    $man_aut = "";
    $env = "Open Innovation";
    $problem_statement_to_display = "";
    $str = "";

    $healthcare .= "
    1.	Health Protection Services <br><br> 2.	Public Health and Surveillance<br><br>
    3.	Health Disparities and Interventions for Persons with Disabilities<br><br>
    4.	Health Care Access and Quality<br><br>
    5.	Currently, Middletown Hospital's largest diagnostic tools are CAT scans and myelograms (spinal cord). <br>
    <br>6.	Create, establish & promote health application systems & services for all including special needs<br>
    <br>7.	Artificial Intelligence-Solve drug design, discovery, vaccine innovation and Precision medicine <br>
    <br>8.	Open innovation<br>
    ";

    $agri = "
    1.	Improvement in the design of food storage structures<br><br>
    2.	IoT enabled micro irrigation and farming land health logging system <br><br>3.	Eco-Harvester for fruits 
    <br><br>4.	Increase the shelf life of fruits and vegetables & Postharvest Processing. 
    <br><br>5.	Rapid detection of bacterial and fungal infections in plants. 
    <br><br>6.	Create solutions that help farmers to identify and implement innovative technology that offers real-time data & predictive analysis
    <br><br>7.	Open innovation
    ";

    $_SESSION['theme_s_for_ps2'] = "Healthcare";
    $problem_statement_to_display = $healthcare;
	if(isset($_POST['problem_submit'])){
        $theme_selected = $_POST['project_theme_selected'];
        if($theme_selected == 'Healthcare'){
            $problem_statement_to_display = $healthcare;

        }
        else if($theme_selected == 'Agriculture'){
            $problem_statement_to_display = $agri;
            $_SESSION['theme_s_for_ps2'] = "Agriculture";
        }
        else if($theme_selected == 'Manufacturing and Automation'){
            $problem_statement_to_display = $man_aut;

        }
        else if($theme_selected == 'Environment'){
            $problem_statement_to_display = $env;
            $_SESSION['theme_s_for_ps2'] = "Environment";
        }
    }

	$str .= "
    <br>
	<div class='status_post'>
        <p class='ps_p'>$problem_statement_to_display</p>
    </div>
    <br>
    <hr style ='color:black;'>";
    				

?>