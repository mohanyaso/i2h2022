<?php
class Post {
	private $con;

	public function __construct($con){
		$this->con = $con;
	}


	public function loadPostsFriends($selected_theme_by_admin) {


		$str = "
		<div class='row' id='admin_row'>
			<div class='column col-md-3 col-sm-3 col-4'>
				<h6 style='color:#5f2780' class='admin_hs'>Title</h4>
			</div>
			<div class='column col-md-3 col-sm-3 col-4'>
				<h6 class='admin_hs' style='color:#5f2780'>Abstract</h4>
			</div>
			<div class='column col-md-3 col-sm-3 col-4'>
				<h6 style='color:#5f2780' class='admin_hs'>Id</h4>
			</div>
			<div class='column col-md-3 col-sm-3 col-0'>
				<h6></h4>
			</div>
		</div>
		<hr>"; 
		$data_query = mysqli_query($this->con, "SELECT * FROM team_members WHERE selected ='yet' AND project_theme = '$selected_theme_by_admin' AND project_title != ''");

		if(mysqli_num_rows($data_query) > 0) {



			while($user_row = mysqli_fetch_array($data_query)) {
				$id = $user_row['team_id'];
				$des = $user_row['project_description'];
				$first_member_name = $user_row['first_member_name'];

					
					$_id = $user_row['team_id'];
					$first_name = $user_row['first_member_name'];
					$second_name = $user_row['second_member_name'];
					$third_name = $user_row['third_member_name'];
					$leader_name = $user_row['leader_name'];
					$mentor_name = $user_row['mentor_name'];

					$project_name = $user_row['project_title'];
					$project_descr = $user_row['project_description'];
					$project_name = ucfirst(strtolower($project_name));
					
					$str .= "
							<br>
							<div class='status_post'>
								<form action='admin.php' id='select_form' method='POST'>
								<div class='row' id='admin_row2'>
									<div class='column col-md-3 col-sm-3 col-4'>
										<h5 class='nt' style='color:#5f2780'>$project_name</h5>
									</div>
									
									<div class='column col-md-3 col-sm-3 col-4' id='drop_div'>
										<input type='button' style='background-color:white;color:#5f2780;' class='click4' id='dropdownMenuButton1' data-bs-toggle='dropdown' aria-expanded='false' value='View'></input>
										<ul class='dropdown-menu'  aria-labelledby='dropdownMenuButton1'>
											<p style='width:100%;height:100%;style='color:#5f2780'' class='des_text'>$project_descr</p>
										</ul>
									</div>
									<div class='column col-md-3 col-sm-3 col-4'>
										<input id='select_id' name='selected_id' style='color:#5f2780' type='text' value='$_id'></input>
									</div>
									<div class='column col-md-3 col-sm-3 col-12'>
										<div class='row'>
											<div class='column col-lg-6 col-md-12 col-sm-12 col-12'>
												<input  name='selected_btn' class='click5' type='submit' id='select_button' value='Select'></input>
											</div>
											<div class='column col-lg-6 col-md-12 col-sm-12 col-12'>
												<input  name='rejected_btn' class='reject_btn' type='submit' id='select_button' value='Reject'></input>
											</div>
										</form>
										</div>
									</div>
								</div>
							<hr>
								";
					
				
			} 
		}
		echo $str;
	}

}

?>